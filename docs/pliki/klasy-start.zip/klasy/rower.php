<?php
// Ćwiczenie 3 — klasa Rower z metodami w PHP.
// Uruchom przez http://localhost/klasy/rower.php

class Rower
{
    // Konstruktor z „promocją” (PHP 8): deklaruje pola i od razu je ustawia.
    public function __construct(
        public string $marka,
        public string $model,
        public int $rok,
        public int $przebiegKm,
    ) {}

    // ZADANIE 1: metoda opis(): string — zwraca np. "Kross Hexagon (2021): 1250 km"
    public function opis(): string
    {
        return '';
    }

    // ZADANIE 2: metoda dodajPrzebieg(int $km): void — zwiększa przebieg o $km


    // ZADANIE 3: metoda potrzebujePrzegladu(): bool — true od 1000 km

}

$rowery = [
    new Rower('Kross', 'Hexagon', 2021, 1250),
    new Rower('Romet', 'Orkan', 2019, 300),
    new Rower('Merida', 'Speeder', 2023, 980),
];

// ZADANIE 4: każdemu rowerowi dodaj 30 km (pętla foreach i metoda dodajPrzebieg).

?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Rowery — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>

  <main>
    <h1>Rowery w serwisie</h1>
    <table>
      <thead>
        <tr><th>Rower</th><th>Przegląd</th></tr>
      </thead>
      <tbody>
<?php foreach ($rowery as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r->opis()) ?></td>
          <td><?= method_exists($r, 'potrzebujePrzegladu') && $r->potrzebujePrzegladu() ? 'tak' : 'nie' ?></td>
        </tr>
<?php endforeach; ?>
      </tbody>
    </table>
    <p><a href="index.html">Powrót</a></p>
  </main>
</body>
</html>
