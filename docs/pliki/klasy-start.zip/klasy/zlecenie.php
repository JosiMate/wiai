<?php
// Ćwiczenie 6 — zlecenie złożone z usług (kompozycja) w PHP 8.1+.
// Uruchom przez http://localhost/klasy/zlecenie.php

enum Status: string
{
    case Przyjete   = 'przyjęte';
    case WNaprawie  = 'w naprawie';
    case Gotowe     = 'gotowe';
    case Odebrane   = 'odebrane';
}

// Usługa: nazwa i cena w groszach. readonly — po utworzeniu nie da się ich zmienić.
class Usluga
{
    public function __construct(
        public readonly string $nazwa,
        public readonly int $cenaGr,
    ) {}
}

class Zlecenie
{
    private array $pozycje = [];        // tablica obiektów Usluga — dostęp tylko przez metody
    public Status $status = Status::Przyjete;

    public function __construct(
        public readonly int $nr,
        public readonly string $rower,
    ) {}

    // ZADANIE 1: dodaj(Usluga $u): void — dopisuje usługę na koniec tablicy $pozycje.


    // ZADANIE 2: suma(): int — suma cen wszystkich pozycji w groszach.
    public function suma(): int
    {
        return 0;
    }

    // Gotowe: zwraca kopię listy pozycji (do wyświetlenia).
    public function pozycje(): array
    {
        return $this->pozycje;
    }
}

function zl(int $grosze): string
{
    return number_format($grosze / 100, 2, ',', ' ') . ' zł';
}

$z = new Zlecenie(101, 'Kross Hexagon');
// ZADANIE 3: dodaj do zlecenia trzy usługi: przegląd 9000 gr, wymiana dętki 3500 gr,
//   regulacja hamulców 4000 gr — i zmień status na Status::WNaprawie.


// ZADANIE 4: usuń // przed wierszem C, odśwież stronę i zapisz komunikat. Potem przywróć //.
// $z->nr = 999;          // wiersz C
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Zlecenie — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>

  <main>
    <h1>Zlecenie <?= $z->nr ?>: <?= htmlspecialchars($z->rower) ?></h1>
    <p>Status: <?= $z->status->value ?></p>
    <table>
      <thead>
        <tr><th>Usługa</th><th>Cena</th></tr>
      </thead>
      <tbody>
<?php foreach ($z->pozycje() as $u): ?>
        <tr><td><?= htmlspecialchars($u->nazwa) ?></td><td><?= zl($u->cenaGr) ?></td></tr>
<?php endforeach; ?>
      </tbody>
    </table>
    <p class="wynik">Razem: <?= zl($z->suma()) ?> (pozycji: <?= count($z->pozycje()) ?>)</p>
    <p><a href="index.html">Powrót</a></p>
  </main>
</body>
</html>
