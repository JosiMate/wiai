// Ćwiczenie 2 — klasa Rower dostaje metody.

console.log("--- ćwiczenie 2: metody ---");

class Rower {
  constructor(marka, model, rok, przebiegKm) {
    this.marka = marka;
    this.model = model;
    this.rok = rok;
    this.przebiegKm = przebiegKm;
  }

  // ZADANIE 1: metoda opis() zwraca napis, np.  Kross Hexagon (2021): 1250 km
  //   (zwraca — return — a nie wypisuje)


  // ZADANIE 2: metoda dodajPrzebieg(km) zwiększa przebiegKm o km.


  // ZADANIE 3: metoda wiek(rokBiezacy) zwraca liczbę lat roweru.


  // ZADANIE 4: metoda potrzebujePrzegladu() zwraca true, gdy przebieg wynosi co najmniej 1000 km.

}

// Odkomentuj kolejne wiersze, gdy dopiszesz metody:
// const kross = new Rower("Kross", "Hexagon", 2021, 1250);
// const romet = new Rower("Romet", "Orkan", 2019, 300);
// kross.dodajPrzebieg(30);
// console.log(kross.opis());                        // Kross Hexagon (2021): 1280 km
// console.log(romet.opis());                        // Romet Orkan (2019): 300 km
// console.log("Wiek Rometa:", romet.wiek(2026));    // 7
// console.log("Kross do przeglądu:", kross.potrzebujePrzegladu());   // true
// console.log("Romet do przeglądu:", romet.potrzebujePrzegladu());   // false
