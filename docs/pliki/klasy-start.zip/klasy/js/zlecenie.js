// Ćwiczenie 7 — zlecenie pilnuje kolejności statusów.

console.log("--- ćwiczenie 7: statusy ---");

const STATUS = Object.freeze({
  PRZYJETE: "przyjęte",
  W_NAPRAWIE: "w naprawie",
  GOTOWE: "gotowe",
  ODEBRANE: "odebrane",
});

// Dozwolone przejścia: przyjęte → w naprawie → gotowe → odebrane. Innych nie ma.
const NASTEPNY = {
  [STATUS.PRZYJETE]: STATUS.W_NAPRAWIE,
  [STATUS.W_NAPRAWIE]: STATUS.GOTOWE,
  [STATUS.GOTOWE]: STATUS.ODEBRANE,
};

class Zlecenie {
  static liczba = 0;            // pole statyczne — wspólne dla całej klasy
  #status = STATUS.PRZYJETE;

  constructor(rower) {
    Zlecenie.liczba++;
    this.nr = 100 + Zlecenie.liczba;
    this.rower = rower;
  }

  get status() {
    return this.#status;
  }

  // ZADANIE 1: zmienStatus(nowy) — zmienia status tylko wtedy, gdy nowy === NASTEPNY[obecny].
  //   W przeciwnym razie: throw new Error(`Nie można zmienić statusu z „${...}” na „${...}”`);


  // ZADANIE 2: toString() zwraca  Zlecenie 101 (Kross Hexagon): gotowe

}

const z1 = new Zlecenie("Kross Hexagon");
const z2 = new Zlecenie("Romet Orkan");

// ZADANIE 3: przeprowadź z1 przez statusy „w naprawie” i „gotowe”, a z2 spróbuj od razu
//   oznaczyć jako „odebrane”. Każdą zmianę wykonaj w try/catch i wypisz błąd.
//   Na końcu wypisz oba zlecenia (`${z1}`) i liczbę zleceń: Zlecenia.liczba
