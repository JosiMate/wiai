// Ćwiczenie 5 — pole prywatne, getter i walidacja.

console.log("--- ćwiczenie 5: hermetyzacja ---");

class LicznikRoweru {
  // ZADANIE 1: pole prywatne #przebiegKm (zaczyna od wartości z konstruktora).

  constructor(marka, przebiegKm) {
    this.marka = marka;
    // przypisz przebieg do pola prywatnego
  }

  // ZADANIE 2: getter przebiegKm — pozwala odczytać przebieg, ale nie zmienić go z zewnątrz.


  // ZADANIE 3: dodajPrzebieg(km). Gdy km nie jest liczbą całkowitą większą od zera,
  //   rzuć błąd:  throw new Error(`Niepoprawny przebieg: ${km}`);


  // ZADANIE 4: toString() zwraca  Kross: 1280 km

}

const licznik = new LicznikRoweru("Kross", 1250);
const proby = [30, -5, "40", 2.5];
for (const km of proby) {
  try {
    licznik.dodajPrzebieg(km);
    console.log(`dodano ${JSON.stringify(km)} → ${licznik.przebiegKm} km`);
  } catch (e) {
    console.log(`Błąd: ${e.message}`);
  }
}
licznik.przebiegKm = 0;          // próba „cofnięcia licznika” z zewnątrz
console.log(`Po próbie cofnięcia: ${licznik}`);
