// Ćwiczenie 8 — zaprojektuj typ Karnet na podstawie opisu i testów.
//
// Klient kupuje karnet na kilka przeglądów (domyślnie 5, najwyżej 20).
//   • new Karnet("Ola")      — karnet na 5 przeglądów,  new Karnet("Jan", 10) — na 10,
//   • liczba przeglądów spoza zakresu 1–20 (albo nie całkowita) → błąd przy tworzeniu,
//   • wykorzystaj()          — zużywa jeden przegląd; gdy nic nie zostało → błąd „Karnet wykorzystany”,
//   • pozostalo              — ile przeglądów zostało; da się odczytać, nie da się zmienić z zewnątrz,
//   • toString()             — „Karnet: Ola, zostało 3 z 5”.
//
// Napisz klasę w miejscu ZADANIE. Testów pod spodem NIE zmieniaj — mają wszystkie dać OK.

console.log("--- ćwiczenie 8: karnet ---");

// ZADANIE: klasa Karnet
class Karnet {}


// ---------------------------------------------------------------- testy
let zaliczone = 0;
function test(nazwa, warunek) {
  let ok = false;
  try { ok = warunek(); } catch (e) { ok = false; }
  if (ok) zaliczone++;
  console.log(`${ok ? "OK   " : "BŁĄD "} ${nazwa}`);
}
function rzuca(f) {
  try { f(); } catch (e) { return true; }
  return false;
}

test("nowy karnet ma 5 przeglądów", () => `${new Karnet("Ola")}` === "Karnet: Ola, zostało 5 z 5");
test("karnet na 10 przeglądów", () => `${new Karnet("Jan", 10)}` === "Karnet: Jan, zostało 10 z 10");
test("dwa razy wykorzystaj → zostały 3", () => {
  const k = new Karnet("Ola");
  k.wykorzystaj();
  k.wykorzystaj();
  return k.pozostalo === 3;
});
test("pozostalo nie da się zmienić z zewnątrz", () => {
  const k = new Karnet("Ola");
  k.pozostalo = 99;
  return k.pozostalo === 5;
});
test("szósty przegląd z pięciu → błąd", () => {
  const k = new Karnet("Ola");
  for (let i = 0; i < 5; i++) k.wykorzystaj();
  return rzuca(() => k.wykorzystaj()) && k.pozostalo === 0;
});
test("karnet na 0, 21 albo 2.5 przeglądu → błąd", () =>
  rzuca(() => new Karnet("Jan", 0)) && rzuca(() => new Karnet("Jan", 21)) && rzuca(() => new Karnet("Jan", 2.5)));

console.log(`Wynik: ${zaliczone}/6`);
