/* Typ Rower w C — ćwiczenie 1. Tylko do czytania.
   Nie uruchamiaj: najpierw zapisz w karcie pracy, co wypisze program.
   Sprawdzić możesz w kompilatorze online (np. godbolt.org, Execute the code). */
#include <stdio.h>

typedef struct {
    char marka[20];
    int rok;
    int przebieg_km;
} Rower;

/* Funkcje „należące” do typu Rower: pierwszy parametr to rower, na którym działają. */
void dodaj_przebieg(Rower *r, int km)       /* wskaźnik: zmienia oryginał */
{
    if (km > 0)
        r->przebieg_km += km;
}

void zeruj_kopie(Rower r)                   /* bez gwiazdki: dostaje KOPIĘ */
{
    r.przebieg_km = 0;
}

void wypisz(Rower r)
{
    printf("%s (%d): %d km\n", r.marka, r.rok, r.przebieg_km);
}

int main(void)
{
    Rower a = {"Kross", 2021, 1250};
    Rower b = a;                            /* przypisanie struktury */

    dodaj_przebieg(&a, 30);
    dodaj_przebieg(&a, -500);
    zeruj_kopie(a);

    wypisz(a);
    wypisz(b);
    printf("Rozmiar typu Rower: %zu bajtow\n", sizeof(Rower));
    return 0;
}
