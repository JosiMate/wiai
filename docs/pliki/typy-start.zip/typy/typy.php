<?php
// Typy wartości w PHP — ćwiczenie 3.
// Uruchom przez http://localhost/typy/typy.php
// Najpierw przewiduj w karcie pracy typ każdej wartości, dopiero potem odśwież stronę.

$probki = [
    ['5', 5],
    ['5.0', 5.0],
    ['"5"', "5"],
    ['true', true],
    ['null', null],
    ['10 / 5', 10 / 5],
    ['7 / 2', 7 / 2],
    ['intdiv(7, 2)', intdiv(7, 2)],
    ['"12.5" + 1', "12.5" + 1],
    ['"007"', "007"],
    ['PHP_INT_MAX', PHP_INT_MAX],
    // ZADANIE: dopisz trzy wiersze w tym samym układzie: ['opis', wyrażenie],
    //   dla wyrażeń:  PHP_INT_MAX + 1   0.1 + 0.2   (int) "12abc"
];

// Zwraca to, co wypisałoby var_dump(), jako tekst — żeby wstawić go do tabeli.
function opisz($wartosc): string
{
    ob_start();
    var_dump($wartosc);
    return trim(ob_get_clean());
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Typy wartości w PHP — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>
  <main>
    <h1>Typy wartości w PHP</h1>
    <table>
      <tr><th>Wyrażenie</th><th>gettype()</th><th>var_dump()</th></tr>
<?php foreach ($probki as [$opis, $wartosc]) { ?>
      <tr>
        <td><code><?php echo htmlspecialchars($opis); ?></code></td>
        <td><?php echo gettype($wartosc); ?></td>
        <td><code><?php echo htmlspecialchars(opisz($wartosc)); ?></code></td>
      </tr>
<?php } ?>
    </table>
    <p>PHP <?php echo PHP_VERSION; ?> · liczba całkowita zajmuje tu
      <?php echo PHP_INT_SIZE; ?> bajtów.</p>
    <p><a href="index.html">Wróć</a></p>
  </main>
</body>
</html>
