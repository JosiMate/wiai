<?php
// Paragon z serwisu „Szprycha” — ćwiczenie 5.
// Uruchom przez http://localhost/typy/paragon.php
// Ceny trzymamy w GROSZACH, jako liczby całkowite (int): 2499 to 24,99 zł.

$pozycje = [
    // nazwa,                cena w groszach, ilość
    ['Przegląd podstawowy',  9000, 5],
    ['Wymiana łańcucha',     6000, 2],
    ['Dętka 28"',            2499, 3],
    ['Smar do łańcucha',     1850, 1],
    ['Tryb ekspresowy',      3000, 1],
];

// ZADANIE 1: zwróć kwotę jako tekst w złotych, z przecinkiem i spacją
// oddzielającą tysiące:  2499 → "24,99 zł",  9000 → "90,00 zł",
// 123456 → "1 234,56 zł". Użyj funkcji number_format().
function zl(int $grosze): string
{
    return '';
}

$suma = 0;
// ZADANIE 2: w pętli po $pozycje dodaj do $suma wartość każdej pozycji
// (cena × ilość). Suma ma zostać liczbą całkowitą — w groszach.

?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Paragon — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>
  <main>
    <h1>Paragon</h1>
<pre class="paragon">
<?php
foreach ($pozycje as [$nazwa, $cena, $ilosc]) {
    // ZADANIE 3: zamień echo na printf tak, żeby ilość zajmowała 3 znaki,
    // a cena 10 znaków, obie wyrównane do prawej, np.:
    //   "  5 x  90,00 zł  Przegląd podstawowy"
    echo $ilosc . ' x ' . zl($cena) . '  ' . $nazwa . "\n";
}
?>
----------------------------------
RAZEM: <?php echo zl($suma); ?>

</pre>
    <p>Typ zmiennej <code>$suma</code>: <strong><?php echo gettype($suma); ?></strong></p>
    <p><a href="index.html">Wróć</a></p>
  </main>
</body>
</html>
