/* Specyfikatory formatu w C — ćwiczenie 2.
   Najpierw przewiduj wynik na kartce. Sprawdzić możesz kompilatorem online,
   np. godbolt.org (włącz okno "Output" przyciskiem "Execute the code"). */
#include <stdio.h>

int main(void) {
    int rowery = 5;
    double cena = 90;
    char klasa = 'B';

    printf("Rowery: %d\n", rowery);
    printf("Cena: %f\n", cena);
    printf("Cena: %.2f zl\n", cena);
    printf("[%5d]\n", rowery);
    printf("[%-5d]\n", rowery);
    printf("[%08.2f]\n", cena * rowery * 0.9);
    printf("Klasa %c, kod %d\n", klasa, klasa);
    printf("%e\n", 1234567.0);
    printf("Rabat 10%%\n");
    printf("%x\n", 255);
    return 0;
}
