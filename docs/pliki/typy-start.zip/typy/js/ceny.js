// Kalkulator części — ćwiczenie 6.
// Cena przychodzi z pola formularza jako TEKST, z przecinkiem, np. "24,99".
// Liczymy w groszach, żeby uniknąć błędów zaokrągleń liczb zmiennoprzecinkowych.

// ZADANIE 1: zamień tekst ceny na liczbę całkowitą groszy.
//   "24,99" → 2499    "90" → 9000    "0,29" → 29    "1,15" → 115
function wGroszach(tekst) {
  return 0;
}

// ZADANIE 2: zamień grosze na tekst do wyświetlenia.
//   2499 → "24,99 zł"    9000 → "90,00 zł"    5 → "0,05 zł"
function naZlote(grosze) {
  return "";
}

document.getElementById("policz").addEventListener("click", function () {
  const cena = wGroszach(document.getElementById("cena").value);
  const ilosc = Number(document.getElementById("ilosc").value);
  const razem = cena * ilosc;
  document.getElementById("wynik").textContent =
    "Razem: " + naZlote(razem) + " (" + razem + " gr, typ: " + typeof razem + ")";
});
