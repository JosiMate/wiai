<?php
// Cennik serwisu — wspólny moduł, dołączany do każdego skryptu wyceny.
// Ten plik niczego nie wypisuje: tylko definiuje dane i funkcję.

$ceny = [
    'przeglad'    => 90,
    'centrowanie' => 45,
    'lancuch'     => 60,
    'amortyzator' => 220,
];
$doplataEkspres = 30;

const PROG_RABATU   = 5;    // rabat od tylu rowerów w zamówieniu
const RABAT_PROCENT = 10;   // wysokość rabatu w procentach

// Zwraca kwotę po rabacie — albo tę samą kwotę, gdy rowerów jest za mało.
function rabat($kwota, $rowery)
{
    if ($rowery >= PROG_RABATU) {
        return $kwota * (100 - RABAT_PROCENT) / 100;
    }
    return $kwota;
}
