<?php
// Dwa rodzaje błędów — do sekcji 3 materiału.
// Uruchom przez http://localhost/srodowisko/bledy.php
echo 'Start<br>';
echo 'Koszt: ' . cena('przeglad') . '<br>';
echo 'Koniec';
