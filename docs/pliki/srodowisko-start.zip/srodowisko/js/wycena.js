// Wycena naprawy z rabatem — liczona w przeglądarce.
// Program uruchamia się bez błędów, ale dla części danych liczy źle.
// Znajdź przyczyny debuggerem: F12 → Źródła (Sources) → js/wycena.js.

const CENY = {
  przeglad: 90,
  centrowanie: 45,
  lancuch: 60,
  amortyzator: 220
};
const DOPLATA_EKSPRES = 30;
const PROG_RABATU = 5;      // rabat od tylu rowerów w zamówieniu
const RABAT_PROCENT = 10;   // wysokość rabatu w procentach

document.getElementById("oblicz").addEventListener("click", function () {
  const usluga = document.getElementById("usluga").value;
  const rowery = Number(document.getElementById("rowery").value);
  const ekspres = document.getElementById("ekspres").checked;

  let razem = CENY[usluga] * rowery;
  if (rowery > PROG_RABATU) {
    razem = razem * RABAT_PROCENT / 100;
  }
  if (ekspres == "tak") {
    razem = razem + DOPLATA_EKSPRES;
  }

  document.getElementById("wynik").textContent = "Szacunkowy koszt: " + razem + " zł";
});
