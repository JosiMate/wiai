<?php
// Wycena naprawy z rabatem — liczona na serwerze.
// Ten plik ma kilka błędów. Szukaj ich po kolei, czytając komunikaty PHP.
require 'cenik.php';

$usluga  = $_GET['usluga'] ?? '';
$rowery  = (int) ($_GET['rowery'] ?? 0);
$ekspres = isset($_GET['ekspres'])

if (!isset($ceny[$usluga]) || $rowery < 1 || $rowery > 20) {
    $komunikat = 'Niepoprawne dane zamówienia.';
} else {
    $razem = policz_rabat($ceny[$usluga] * $rowery, $rowery);
    if ($ekspres) {
        $razem = $razem + $doplataEkspres;
    }
    $komunikat = 'Szacunkowy koszt: ' . $razem . ' zł';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Wynik wyceny — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>
  <main>
    <h1>Wynik wyceny</h1>
    <p class="wynik"><?php echo htmlspecialchars($komunikat); ?></p>
    <p>Wycena przygotowana <?php echo date('d.m.Y, H:i'); ?>.</p>
    <p><a href="index.html">Wróć do formularza</a></p>
  </main>
</body>
</html>
