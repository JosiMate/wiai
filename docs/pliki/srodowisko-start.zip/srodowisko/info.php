<?php
// Strona informacyjna PHP: wersja, wczytany plik php.ini, włączone moduły.
// Na serwerze produkcyjnym nie zostawia się takiego pliku — zdradza konfigurację.
phpinfo();
