// Wycena naprawy liczona w przeglądarce.
// Uzupełnij kod w miejscach oznaczonych ZADANIE — w tej kolejności.

const CENY = {
  przeglad: 90,
  centrowanie: 45,
  lancuch: 60,
  amortyzator: 220
};
const DOPLATA_EKSPRES = 30;

// ZADANIE 1: wypisz w konsoli przeglądarki komunikat, że skrypt się wczytał.
//            Sprawdź go w narzędziach deweloperskich (F12 → Console).


document.getElementById("oblicz").addEventListener("click", function () {
  // ZADANIE 2: odczytaj z formularza wybraną usługę (pole "usluga"),
  //            liczbę rowerów (pole "rowery") i to, czy zaznaczono
  //            tryb ekspresowy (pole "ekspres", właściwość checked).


  // ZADANIE 3: policz koszt: cena usługi z obiektu CENY × liczba rowerów,
  //            a przy trybie ekspresowym dolicz DOPLATA_EKSPRES.


  // ZADANIE 4: wpisz wynik do akapitu o identyfikatorze "wynik",
  //            na przykład: "Szacunkowy koszt: 300 zł".

});
