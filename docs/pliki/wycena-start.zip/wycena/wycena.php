<?php
// Wycena naprawy liczona na serwerze.
// Ten plik działa TYLKO przez serwer: http://localhost/wycena/
// Otwarty podwójnym kliknięciem pokaże kod albo nic.

$ceny = [
    'przeglad'    => 90,
    'centrowanie' => 45,
    'lancuch'     => 60,
    'amortyzator' => 220,
];
$doplataEkspres = 30;

// ZADANIE 1: odczytaj dane przysłane z formularza. Są w tablicy $_GET
//            pod nazwami pól: 'usluga', 'rowery', 'ekspres'.
//            Uwaga: pole 'ekspres' przychodzi TYLKO wtedy, gdy je zaznaczono.


// ZADANIE 2: policz koszt tak samo jak w JavaScripcie
//            i zapisz tekst wyniku w zmiennej $komunikat.
$komunikat = 'Tu pojawi się wynik wyceny.';

?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Wynik wyceny — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>
  <main>
    <h1>Wynik wyceny</h1>
    <p class="wynik"><?php echo $komunikat; ?></p>
    <p>Wycena przygotowana <?php echo date('d.m.Y, H:i'); ?>.</p>
    <p><a href="index.html">Wróć do formularza</a></p>
  </main>
</body>
</html>
