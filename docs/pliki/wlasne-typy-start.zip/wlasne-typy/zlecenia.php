<?php
// Enum i klasa w PHP — ćwiczenie 8. Wymaga PHP 8.1 lub nowszego (XAMPP 8.2 — tak).
// Uruchom przez http://localhost/wlasne-typy/zlecenia.php

enum Status: string
{
    case Przyjete   = 'przyjęte';
    case WNaprawie  = 'w naprawie';
    case Gotowe     = 'gotowe';
    case Odebrane   = 'odebrane';
}

class Zlecenie
{
    public int $nr;
    public string $rower;
    public Status $status;
    public int $cenaGr;

    public function __construct(int $nr, string $rower, Status $status, int $cenaGr)
    {
        $this->nr = $nr;
        $this->rower = $rower;
        // ZADANIE 1: dokończ konstruktor — przypisz dwa pozostałe pola.
    }
}

// ZADANIE 2: uzupełnij tablicę czterema zleceniami (new Zlecenie(...)):
//   101, 'Kross Hexagon',  Status::Gotowe,    12500
//   102, 'Romet Orkan',    Status::WNaprawie,  9000
//   103, 'Merida Speeder', Status::Gotowe,     4000
//   104, 'Kands Comfort',  Status::Przyjete,   9000
$zlecenia = [];

// ZADANIE 3: policz zlecenia ze statusem Status::Gotowe i ich łączną kwotę w groszach.
$doOdbioru = 0;
$kwotaGr = 0;


// ZADANIE 4: usuń // przed wierszem C, odśwież stronę i zapisz komunikat. Potem przywróć //.
// $zlecenia[] = new Zlecenie(105, 'Unibike Viper', 'gotowe', 6000);   // wiersz C

function zl(int $grosze): string
{
    return number_format($grosze / 100, 2, ',', ' ') . ' zł';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Zlecenia — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>

  <main>
    <h1>Zlecenia serwisu</h1>

    <table>
      <thead>
        <tr><th>Nr</th><th>Rower</th><th>Status</th><th>Kwota</th></tr>
      </thead>
      <tbody>
<?php foreach ($zlecenia as $z): ?>
        <tr>
          <td><?= $z->nr ?></td>
          <td><?= htmlspecialchars($z->rower) ?></td>
          <td><?= $z->status->value ?></td>
          <td><?= zl($z->cenaGr) ?></td>
        </tr>
<?php endforeach; ?>
      </tbody>
    </table>

    <p class="wynik">Do odbioru: <?= $doOdbioru ?> zlecenia na <?= zl($kwotaGr) ?>.</p>

    <p><a href="index.html">Powrót</a></p>
  </main>
</body>
</html>
