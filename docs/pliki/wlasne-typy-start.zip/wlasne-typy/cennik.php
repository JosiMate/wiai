<?php
// Tablica asocjacyjna w PHP — ćwiczenie 3.
// Uruchom przez http://localhost/wlasne-typy/cennik.php

$cennik = [
    'przegląd'           => 90,
    'wymiana dętki'      => 35,
    'regulacja hamulców' => 40,
    'centrowanie koła'   => 50,
];

// ZADANIE 1: dopisz do tablicy usługę 'wymiana linki' za 30 zł (jednym przypisaniem, bez zmiany wierszy wyżej).


// ZADANIE 2: w akapicie z klasą "wynik" (niżej, w HTML) wypisz cenę przeglądu odczytaną z tablicy.

// ZADANIE 3: w tabeli niżej uzupełnij pętlę foreach, a tu policz sumę cen wszystkich usług.
$suma = 0;


// ZADANIE 4: usuń // przed wierszem B, odśwież stronę i zapisz komunikat. Potem przywróć //.
// echo $cennik['Przegląd'];          // wiersz B
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cennik — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>

  <main>
    <h1>Cennik usług</h1>

    <p class="wynik">Przegląd kosztuje ... zł.</p>

    <table>
      <thead>
        <tr><th>Usługa</th><th>Cena</th></tr>
      </thead>
      <tbody>
<?php /* ZADANIE 3: foreach ($cennik as $usluga => $cena): ?>
        <tr><td><?= $usluga ?></td><td><?= $cena ?> zł</td></tr>
<?php endforeach; */ ?>
      </tbody>
    </table>

    <p>Liczba usług: <?= count($cennik) ?>. Wszystkie razem: <?= $suma ?> zł.</p>

    <p><a href="index.html">Powrót</a></p>
  </main>
</body>
</html>
