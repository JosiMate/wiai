// Ćwiczenie 7 — klasa Rower: szablon, z którego powstają obiekty.

console.log("--- ćwiczenie 7: klasa Rower ---");

class Rower {
  constructor(marka, model, rok) {
    this.marka = marka;
    this.model = model;
    this.rok = rok;
    // ZADANIE 1: dodaj pole przebiegKm z wartością przekazaną jako czwarty parametr konstruktora.
  }
}

// ZADANIE 2: utwórz stałą tablicę rowery z trzema obiektami klasy Rower:
//   "Kross", "Hexagon", 2021, 1250
//   "Romet", "Orkan",   2019, 4300
//   "Merida", "Speeder", 2023, 380
//   Wypisz ją: console.table(rowery)


// ZADANIE 3: wypisz każdy rower w jednym wierszu, np.  Kross Hexagon (2021): 1250 km
//   i na końcu łączny przebieg wszystkich rowerów:  Razem: 5930 km


// ZADANIE 4: sprawdź i wypisz:
//   rowery[0] instanceof Rower
//   typeof rowery[0]
//   Potem odkomentuj wiersz D, zapisz komunikat z konsoli i zakomentuj go z powrotem.
// const zly = Rower("Kands", "Comfort", 2020, 900);   // wiersz D
