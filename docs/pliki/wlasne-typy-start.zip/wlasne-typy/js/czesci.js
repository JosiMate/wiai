// Ćwiczenie 2 — tablica części w magazynie serwisu.

console.log("--- ćwiczenie 2: tablica części ---");

// ZADANIE 1: utwórz stałą tablicę czesci z trzema napisami:
//   "dętka 28 cali", "łańcuch", "klocki hamulcowe"
//   Wypisz liczbę elementów (length), pierwszy element i ostatni element.
//   Ostatni wypisz tak, żeby kod działał dla tablicy dowolnej długości: czesci[czesci.length - 1]


// ZADANIE 2: dopisz na koniec tablicy "linka hamulcowa" (metoda push)
//   i ponownie wypisz liczbę elementów.


// ZADANIE 3: wypisz czesci[10]. Zapisz w karcie, co pokazała konsola.


// ZADANIE 4: wypisz wszystkie części z numerami od 1, np. "1. dętka 28 cali".
//   Uzupełnij pętlę:
// for (let i = 0; i < czesci.length; i++) {
//   console.log(`${i + 1}. ${...}`);
// }
