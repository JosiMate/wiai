// Ćwiczenie 5 — statusy i lista zleceń.
// JavaScript nie ma słowa enum. Zastępuje go zamrożony obiekt ze stałymi.

console.log("--- ćwiczenie 5: zlecenia ---");

const STATUS = Object.freeze({
  PRZYJETE: "przyjęte",
  W_NAPRAWIE: "w naprawie",
  GOTOWE: "gotowe",
  ODEBRANE: "odebrane",
});

// ZADANIE 1: utwórz stałą tablicę zlecenia z czterema obiektami. Każdy ma pola nr, rower i status:
//   101, "Kross Hexagon", STATUS.GOTOWE
//   102, "Romet Orkan",   STATUS.W_NAPRAWIE
//   103, "Merida Speeder", STATUS.GOTOWE
//   104, "Kands Comfort", STATUS.PRZYJETE
//   Wypisz tablicę jako tabelę: console.table(zlecenia)


// ZADANIE 2: zlecenie 102 zostało naprawione. Zmień jego status na STATUS.GOTOWE
//   (to drugi element tablicy — indeks?) i wypisz tabelę jeszcze raz.


// ZADANIE 3: policz zlecenia gotowe do odbioru i wypisz:
//   Do odbioru: 3 (101, 102, 103)
//   Uzupełnij:
// let doOdbioru = [];
// for (const z of zlecenia) {
//   if (z.status === STATUS.GOTOWE) { ... }
// }


// ZADANIE 4: spróbuj zmienić stałą: STATUS.GOTOWE = "zrobione";
//   Potem wypisz STATUS.GOTOWE. Czy pojawił się błąd? Co się stało?
