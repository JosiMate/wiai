/* Tablice w C — ćwiczenie 1. Tylko do czytania.
   Nie uruchamiaj: najpierw zapisz w karcie pracy, co wypisze program.
   Sprawdzić możesz w kompilatorze online (np. godbolt.org, Execute the code). */
#include <stdio.h>

int main(void)
{
    int ceny[5] = {2500, 4500, 9000, 1200, 3000};   /* ceny części w groszach */
    int sprzedane[4] = {3};                         /* podana jest tylko pierwsza wartość */
    char serwis[] = "Szprycha";                     /* napis to tablica znaków */
    int suma = 0;

    for (int i = 0; i < 5; i++)
        suma = suma + ceny[i];

    printf("Pierwsza: %d, ostatnia: %d\n", ceny[0], ceny[4]);
    printf("Suma: %d gr\n", suma);
    printf("Sprzedane: %d %d\n", sprzedane[0], sprzedane[3]);
    printf("Elementow: %zu, bajtow: %zu\n", sizeof ceny / sizeof ceny[0], sizeof ceny);
    printf("Napis: %s, bajtow: %zu\n", serwis, sizeof serwis);
    /* printf("Szosta: %d\n", ceny[5]); */          /* wiersz A — co się stanie? */
    return 0;
}
