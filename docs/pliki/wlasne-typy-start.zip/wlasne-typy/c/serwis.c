/* Enum, struktura i unia w C — ćwiczenie 6. Tylko do czytania.
   Nie uruchamiaj: najpierw zapisz w karcie pracy, co wypisze program.
   Sprawdzić możesz w kompilatorze online (np. godbolt.org, Execute the code). */
#include <stdio.h>

enum Status { PRZYJETE, W_NAPRAWIE, GOTOWE, ODEBRANE };

struct Zlecenie {
    int nr;
    char rower[20];
    enum Status status;
    int cena_gr;
};

union Kwota {
    int grosze;
    double zlote;
};

int main(void)
{
    struct Zlecenie z = {101, "Kross Hexagon", W_NAPRAWIE, 9000};
    union Kwota k;

    z.status = GOTOWE;
    z.cena_gr = z.cena_gr + 3500;
    printf("Zlecenie %d: %s, status %d, %d gr\n", z.nr, z.rower, z.status, z.cena_gr);
    printf("ODEBRANE = %d\n", ODEBRANE);

    k.grosze = 12500;
    printf("Grosze: %d\n", k.grosze);
    k.zlote = 125.0;
    printf("Grosze po zapisie zlotych: %d\n", k.grosze);

    printf("Rozmiar unii: %zu, rozmiar struktury: %zu\n",
           sizeof(union Kwota), sizeof(struct Zlecenie));
    return 0;
}
