// Ćwiczenie 4 — porównania w JavaScripcie: == i ===.
// ZANIM odświeżysz stronę, wpisz w karcie pracy przewidywanie dla każdego wiersza.

console.log("--- ćwiczenie 4: porównania ---");

console.log('1.  "5" == 5           →', "5" == 5);
console.log('2.  "5" === 5          →', "5" === 5);
console.log('3.  0 == ""            →', 0 == "");
console.log('4.  null == undefined  →', null == undefined);
console.log('5.  null === undefined →', null === undefined);
console.log('6.  NaN == NaN         →', NaN == NaN);
console.log('7.  "10" < "9"         →', "10" < "9");
console.log('8.  "10" < 9           →', "10" < 9);

// ZADANIE 1: dopisz dwa własne porównania, których wynik cię zaskoczy albo nie.


// ZADANIE 2: kod do szafki z rowerem przychodzi z formularza — zawsze jako TEKST.
//   Funkcja poniżej zawsze odpowiada „false”, nawet dla dobrego kodu. Popraw ją tak,
//   żeby dla "1234" odpowiadała true, a dla "1235" false. Nie zmieniaj operatora ===.
function kodPoprawny(kodZFormularza) {
  return kodZFormularza === 1234;
}
console.log("Kod 1234 poprawny:", kodPoprawny("1234"));
console.log("Kod 1235 poprawny:", kodPoprawny("1235"));
