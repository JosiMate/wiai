// Ćwiczenie 7 — uprawnienia w panelu serwisu zapisane w bitach jednej liczby.

console.log("--- ćwiczenie 7: uprawnienia ---");

const ODCZYT   = 1;   // 0001
const EDYCJA   = 2;   // 0010
const USUWANIE = 4;   // 0100
const RAPORTY  = 8;   // 1000

// Zwraca uprawnienia jako cztery cyfry dwójkowe, np. 3 → "0011".
function bity(liczba) {
  return liczba.toString(2).padStart(4, "0");
}

let mechanik = ODCZYT | EDYCJA;
console.log(`mechanik: ${mechanik} (${bity(mechanik)})`);

// ZADANIE 1: kierownik ma wszystkie cztery uprawnienia. Połącz je operatorem |
//   i wypisz:  kierownik: 15 (1111)


// ZADANIE 2: uzupełnij funkcję — ma zwracać true, gdy w liczbie upr jest zapalony bit flaga.
//   Uwaga na nawiasy! Wypisz:  mechanik może usuwać: false   i   mechanik może edytować: true
function ma(upr, flaga) {
  return false;
}


// ZADANIE 3: mechanik dostaje RAPORTY (operator |=) i traci EDYCJA (operator &= z ~).
//   Wypisz:  mechanik po zmianach: 9 (1001)


// ZADANIE 4: odkomentuj wiersz D. Dlaczego wynik jest „1”, skoro mechanik nie może usuwać?
// console.log("wiersz D:", mechanik & USUWANIE !== 0);
