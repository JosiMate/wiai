// Ćwiczenie 8 — napraw skrypt.
// W tym pliku jest pięć błędów w operatorach. Żaden nie daje komunikatu w konsoli:
// skrypt działa, tylko liczy źle. Szukaj ich po kolei, porównując wynik z oczekiwanym.
// Gdy skrypt jest poprawny, wypisze:
//   Do zapłaty: 200 zł
//   Serwis zamknięty (godzina 19)
//   Powierzchnia stanowiska: 9 m²
//   Zlecenie 1046: stanowisko B

console.log("--- ćwiczenie 8: napraw skrypt ---");

const cenaPrzegladu = 90;
const iloscRowerow = "2";           // z formularza — tekst
const dostawa = "20";               // z formularza — tekst
let suma = cenaPrzegladu * iloscRowerow;
suma = suma + dostawa;

let czyStalyKlient = false;
if (czyStalyKlient = true) {        // stały klient ma 10% rabatu
  suma = suma * 0.9;
}
console.log(`Do zapłaty: ${suma} zł`);

const godzina = 19;                 // serwis jest otwarty od 8 do 18
if (godzina >= 8 || godzina < 18) {
  console.log(`Serwis otwarty (godzina ${godzina})`);
} else {
  console.log(`Serwis zamknięty (godzina ${godzina})`);
}

const bok = 3;                      // stanowisko jest kwadratem o boku 3 m
const powierzchnia = bok ^ 2;
console.log(`Powierzchnia stanowiska: ${powierzchnia} m²`);

const nrZlecenia = 1046;            // zlecenia o numerze parzystym — stanowisko B
const stanowisko = nrZlecenia % 2 === 1 ? "B" : "A";
console.log(`Zlecenie ${nrZlecenia}: stanowisko ${stanowisko}`);
