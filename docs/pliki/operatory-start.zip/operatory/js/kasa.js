// Ćwiczenie 2 — kasa serwisu: dzielenie, reszta z dzielenia, inkrementacja.

console.log("--- ćwiczenie 2: kasa ---");

// ZADANIE 1: zamień czas naprawy w minutach na godziny i minuty.
//   Godziny: dzielenie bez części ułamkowej — Math.floor(...). Minuty: reszta z dzielenia — %.
//   Wypisz:  Czas naprawy: 2 h 15 min
const czasMin = 135;


// ZADANIE 2: zlecenia o numerze parzystym trafiają na stanowisko B.
//   Wypisz resztę z dzielenia numeru przez 2:  Zlecenie 1046, reszta z dzielenia przez 2: 0
const nrZlecenia = 1046;


// ZADANIE 3: wydaj resztę 87 zł jak najmniejszą liczbą banknotów i monet.
//   Uzupełnij dwa wiersze w pętli. Ma wyjść: 50 zł × 1, 20 zł × 1, 10 zł × 1, 5 zł × 1, 2 zł × 1
let doWydania = 87;
const nominaly = [50, 20, 10, 5, 2, 1];
for (const n of nominaly) {
  const ile = 0;            // ile razy n mieści się w doWydania?
  doWydania = doWydania;    // ile zostaje do wydania?
  if (ile > 0) {
    console.log(`${n} zł × ${ile}`);
  }
}

// ZADANIE 4: licznik klientów. Zacznij od 0, zwiększ trzy razy operatorem ++,
//   potem dodaj 10 operatorem +=. Wypisz:  Klientów: 13
