/* Operatory w C — ćwiczenie 3. Tylko do czytania.
   Nie uruchamiaj: najpierw zapisz w karcie pracy, co wypisze program.
   Sprawdzić możesz w kompilatorze online (np. godbolt.org, Execute the code). */
#include <stdio.h>

int main(void)
{
    int rowery = 7;
    int stanowiska = 2;
    int licznik = 5;
    int a, b;

    printf("Na stanowisko: %d, zostaje: %d\n", rowery / stanowiska, rowery % stanowiska);
    printf("Srednio: %.1f\n", (double) rowery / stanowiska);
    printf("Srednio inaczej: %.1f\n", (double) (rowery / stanowiska));
    printf("Wynik: %d, z nawiasem: %d\n", 2 + 3 * 4, (2 + 3) * 4);

    a = licznik++;
    b = ++licznik;
    printf("a=%d b=%d licznik=%d\n", a, b, licznik);

    licznik += 10;
    licznik *= 2;
    printf("Po += i *=: %d\n", licznik);
    printf("Czy 7 > 2? %d\n", rowery > stanowiska);

    /* printf("%d\n", rowery / 0); */   /* wiersz A — co się stanie? */
    return 0;
}
