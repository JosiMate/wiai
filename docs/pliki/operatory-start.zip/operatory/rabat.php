<?php
// Warunek rabatu — ćwiczenie 5.
// Uruchom przez http://localhost/operatory/ (odnośniki na stronie startowej).
//
// Zasady serwisu:
//   • rabat 10% dostaje stały klient (co najmniej 5 wizyt) ALBO zamówienie za co najmniej 300 zł,
//   • ale nigdy przy trybie ekspresowym,
//   • kwota musi być większa od zera — inaczej komunikat „Niepoprawne dane zamówienia.”

// ZADANIE 1: odczytaj dane z adresu. Gdy parametru nie ma, przyjmij 0 (operator ??).
//   ekspres ma być prawdą, gdy parametr jest w adresie: isset($_GET['ekspres'])
$kwota   = 0;
$wizyty  = 0;
$ekspres = false;

// ZADANIE 2: jedno wyrażenie logiczne z operatorami ||, && i ! — czy klient dostaje rabat?
$czyRabat = false;

// ZADANIE 3: kwota do zapłaty — z rabatem albo bez.
$doZaplaty = $kwota;

// ZADANIE 4: gdy kwota nie jest większa od zera, komunikat ma brzmieć „Niepoprawne dane zamówienia.”
$komunikat = 'Do zapłaty: ' . number_format($doZaplaty, 2, ',', ' ') . ' zł'
           . ' (rabat: ' . ($czyRabat ? 'tak' : 'nie') . ')';
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Rabat — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p>Szprycha — serwis rowerowy</p>
  </header>

  <main>
    <h1>Rabat</h1>
    <p>Kwota: <?= $kwota ?> zł · wizyty: <?= $wizyty ?> · tryb ekspresowy: <?= $ekspres ? 'tak' : 'nie' ?></p>
    <p class="wynik"><?= htmlspecialchars($komunikat) ?></p>
    <p><a href="index.html">Powrót</a></p>
  </main>
</body>
</html>
