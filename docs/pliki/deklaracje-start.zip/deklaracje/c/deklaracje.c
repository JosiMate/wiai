/* Deklaracje w C — ćwiczenie 1. Tylko do czytania.
   Nie uruchamiaj: najpierw zapisz w karcie pracy, co wypisze program.
   Sprawdzić możesz w kompilatorze online (np. godbolt.org, Execute the code). */
#include <stdio.h>

#define STAWKA_VAT 0.23         /* stała preprocesora: bez typu, bez średnika */

int main(void)
{
    const int MAX_ROWEROW = 5;  /* stała z typem */
    int rowery = 2;             /* deklaracja z inicjalizacją */
    double cena = 90.0;
    char klasa = 'B';
    int raty = 2.9;             /* liczba z przecinkiem trafia do int */
    int kupione;                /* sama deklaracja, bez wartości */

    kupione = rowery + 1;       /* przypisanie */
    /* MAX_ROWEROW = 6; */      /* wiersz A — co się stanie, gdy usuniesz komentarz? */

    printf("Rowery: %d z %d\n", kupione, MAX_ROWEROW);
    printf("Brutto: %.2f zl\n", cena * (1 + STAWKA_VAT));
    printf("Klasa %c, raty: %d\n", klasa, raty);
    return 0;
}
