// Ćwiczenie 5 — kalkulator koszyka części.
// Ceny trzymamy w groszach (temat o typach danych): 2500 gr = 25,00 zł.

console.log("--- ćwiczenie 5: koszyk ---");

// ZADANIE 1: zadeklaruj
//   stałą STAWKA_VAT = 0.23
//   stałą cenaDetkiGr = 2500        (cena netto jednej dętki w groszach)
//   zmienną iloscSztuk = 3


// ZADANIE 2: oblicz koszt netto i brutto w groszach.
//   Brutto zaokrąglij do pełnego grosza: Math.round(...)
//   Zastanów się, które wartości będą się zmieniać (let), a które nie (const).


// ZADANIE 3: wypisz komunikat szablonem tekstu (grawis ` i ${...}), np.:
//   Zamówiono 3 szt. Netto: 75.00 zł, brutto: 92.25 zł.
//   Grosze zamienisz na złote: (grosze / 100).toFixed(2)


// ZADANIE 4: zmień iloscSztuk na 5, przelicz netto i brutto jeszcze raz i wypisz nowy komunikat.

