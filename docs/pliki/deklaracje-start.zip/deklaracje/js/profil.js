// Ćwiczenie 2 — profil klienta serwisu.
// Wynik zobaczysz w konsoli: F12 → Konsola, potem odśwież stronę (F5).

console.log("--- ćwiczenie 2: profil klienta ---");

// ZADANIE 1: zadeklaruj dwie STAŁE (const):
//   nazwaSerwisu  — tekst "Szprycha"
//   idUzytkownika — liczba 1042


// ZADANIE 2: zadeklaruj cztery ZMIENNE (let):
//   imieUzytkownika       — dowolne imię (tekst)
//   wiekUzytkownika       — liczba
//   czyAktywny            — true albo false
//   ostatniaWypozyczalnia — bez wartości (sama deklaracja)


// ZADANIE 3: wypisz każdą stałą i zmienną razem z jej typem, np.:
//   console.log("nazwaSerwisu:", nazwaSerwisu, typeof nazwaSerwisu);

