// Ćwiczenie 6 — napraw skrypt.
// W tym pliku jest pięć błędów związanych z deklaracjami. Konsola pokazuje zawsze
// tylko JEDEN — pierwszy, na który trafi. Popraw go, zapisz, odśwież stronę
// i dopiero wtedy szukaj następnego. Ostatni błąd nie daje żadnego komunikatu.
// Gdy skrypt jest poprawny, wypisze: Szprycha: zlecenia 1, do zapłaty 96 zł

const SERWIS = "Szprycha";
const GODZINA_OTWARCIA;

let liczbaZlecen = 0;
let liczbaZlecen = 1;

console.log("Rabat:", rabat);
let rabat = 0.1;

const cenaPrzegladu = 90;
cenaPrzegladu = cenaPrzegladu * (1 - rabat);

const dostawa = "15";
const doZaplaty = cenaPrzegladu + dostawa;

console.log(`${SERWIS}: zlecenia ${liczbaZlecen}, do zapłaty ${doZaplaty} zł`);
console.log("Otwarte od godziny", GODZINA_OTWARCIA);
