// Ćwiczenie 3 — zmienna, stała i stała tablica.

console.log("--- ćwiczenie 3: zmienna i stała ---");

let punktyLojalnosciowe = 100;
// ZADANIE 1: zwiększ punktyLojalnosciowe o 25 i wypisz nową wartość.


const maksymalnyRabat = 0.30;
// ZADANIE 2: przypisz stałej maksymalnyRabat wartość 0.50 i wypisz ją.
//   Zapisz, odśwież stronę i przeczytaj komunikat w konsoli.
//   Potem zakomentuj wiersz z przypisaniem (Ctrl + /), żeby skrypt szedł dalej.


const koszyk = ["dętka 28 cali"];
// ZADANIE 3: dopisz do koszyka "łańcuch" metodą push i wypisz koszyk oraz jego długość:
//   koszyk.push("łańcuch");
//   console.log(koszyk, koszyk.length);
//   Czy skrypt zgłosił błąd? Co więc właściwie chroni const?

