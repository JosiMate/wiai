<?php
// Zmienne i stałe w PHP — ćwiczenie 7.
// Uruchom przez http://localhost/deklaracje/deklaracje.php
// Najpierw przewiduj w karcie pracy, dopiero potem odśwież stronę.

define('NAZWA_SERWISU', 'Szprycha');   // stała przez funkcję define()
const STAWKA_VAT = 0.23;               // stała przez słowo const

$cenaPrzegladu = 90;                   // zmienna: dolar + nazwa, bez słowa deklaracji
$liczbaRowerow = "2";                  // tak przychodzi wartość z formularza — jako tekst
$czyRabat = true;

// ZADANIE 1: zadeklaruj zmienną $netto = cena przeglądu razy liczba rowerów.
//   Przed odświeżeniem strony zapisz w karcie, jaki typ będzie miała $liczbaRowerow, a jaki $netto.
$netto = 0;

// ZADANIE 2: zadeklaruj stałą RABAT = 0.1 słowem const (u góry pliku, pod STAWKA_VAT),
//   a tu — jeśli $czyRabat — zmniejsz $netto o rabat.


$brutto = round($netto * (1 + STAWKA_VAT), 2);

// ZADANIE 3: usuń // przed wierszem B, odśwież stronę i zapisz komunikat. Potem przywróć //.
// echo $cenaPrzegladow;          // wiersz B

// ZADANIE 4: to samo z wierszem C.
// define('STAWKA_VAT', 0.08);    // wiersz C

// Zwraca to, co wypisałoby var_dump(), jako tekst — żeby wstawić go do tabeli.
function opisz($wartosc): string
{
    ob_start();
    var_dump($wartosc);
    return trim(ob_get_clean());
}

$wiersze = [
    ['NAZWA_SERWISU', NAZWA_SERWISU],
    ['STAWKA_VAT', STAWKA_VAT],
    ['$cenaPrzegladu', $cenaPrzegladu],
    ['$liczbaRowerow', $liczbaRowerow],
    ['$czyRabat', $czyRabat],
    ['$netto', $netto],
    ['$brutto', $brutto],
];
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Zmienne i stałe w PHP — Szprycha</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <p><?= NAZWA_SERWISU ?> — serwis rowerowy</p>
  </header>

  <main>
    <h1>Zmienne i stałe w PHP</h1>

    <table>
      <thead>
        <tr><th>Nazwa</th><th>var_dump()</th><th>gettype()</th></tr>
      </thead>
      <tbody>
<?php foreach ($wiersze as [$nazwa, $wartosc]): ?>
        <tr>
          <td><code><?= htmlspecialchars($nazwa) ?></code></td>
          <td><code><?= htmlspecialchars(opisz($wartosc)) ?></code></td>
          <td><?= gettype($wartosc) ?></td>
        </tr>
<?php endforeach; ?>
      </tbody>
    </table>

    <p class="wynik">Do zapłaty za <?= $liczbaRowerow ?> rowery: <?= number_format($brutto, 2, ',', ' ') ?> zł brutto</p>

    <p><a href="index.html">Powrót</a></p>
  </main>
</body>
</html>
